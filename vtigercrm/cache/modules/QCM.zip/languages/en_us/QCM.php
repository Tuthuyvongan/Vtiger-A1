<?php

$languageStrings = array(
        'LBL_QCM_SUMMARY' => 'QCM Summary',
        'LBL_QCM_DETAIL' => 'QCM Details',
        'SINGLE_QCM' => 'QCM',
);