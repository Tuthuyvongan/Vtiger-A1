<?php
/**
 * Created by PhpStorm.
 * User: Netbase
 * Date: 4/23/2019
 * Time: 9:52 AM
 */

class Candidates_Record_Model extends Vtiger_Record_Model {

}