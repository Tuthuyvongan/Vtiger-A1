<?php

$languageStrings = array(
        'LBL_CANDIDATE_INFORMATION' => 'Candidate',
        'LBL_SHORTLIST' => 'Shortlist',
        'LBL_REJECT' => 'Reject',
        'LBL_SCHEDULE_INTERVIEW' => 'Schedule Interview',
        'LBL_MARK_INTERVEW_PASSED' => 'Mark Interview Passed',
		'LBL_MARK_INTERVEW_FAILED' => 'Mark Interview Failed',
    'SINGLE_Candidates' => 'Candidate',
    'LBL_OFFER_JOB'=>'Offer Job'
);