<?php

$languageStrings = array(
        'LBL_STW_INFORMATION' => 'Setting Weight',
        'SINGLE_SettingWeight' => 'Setting Weight'
);