<?php

$languageStrings = array(
        'LBL_JD_INFORMATION' => 'JD Detail',
        'SINGLE_JD' => 'JD',
);