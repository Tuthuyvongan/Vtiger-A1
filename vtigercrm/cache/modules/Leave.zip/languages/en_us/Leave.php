<?php

$languageStrings = array(
        'LBL_LEAVE_INFORMATION' => 'Basic Information',
        'SINGLE_Leave' => 'Leave'
);