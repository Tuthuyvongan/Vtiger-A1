<?php

$languageStrings = array(
        'LBL_SH_INFORMATION' => 'Setting HRM',
        'SINGLE_SettingHrm' => 'Setting HRM'
);