<?php

$languageStrings = array(
        'LBL_PERSONAL_DETAIL' => 'Personal Details',
        'SINGLE_Employee' => 'Employee',
        'LBL_MODULE_NAME' => 'HRM',
        'LBL_INSTALL' => 'Install',
        'LBL_CHANGE_COMPANY_INFORMATION' => 'Change Company Information',
        'LBL_VALIDATE' => 'Active',
        'LBL_ORDER_NOW' => 'Order now',
        'LBL_LICENSE' => 'License settings',
        'LBL_URL' => 'Your vtiger url',
        'LBL_LICENSE_KEY' => 'License key',
        'LBL_COMPANY_LICENSE_INFO' => 'Your Company Information',
        'LBL_REACTIVATE' => 'Reactivate license',
        'LBL_DEACTIVATE' => 'Deactivate license',
    "LBL_DEACTIVATE_QUESTION"=>"Do You realy want to deactivate Your license key?",
);