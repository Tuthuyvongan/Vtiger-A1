<?php

$languageStrings = array(
        'LBL_Salary_INFORMATION' => 'Basic Information',
        'SINGLE_Salary' => 'Salary'
);