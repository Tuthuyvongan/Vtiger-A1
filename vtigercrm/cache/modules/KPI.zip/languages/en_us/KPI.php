<?php

$languageStrings = array(
    'LBL_KPI_INFORMATION' => 'KPI Information',
    'LBL_EXPECT_ACTUAL' => 'Expectations & Actuals',
    'SINGLE_KPI' => 'KPI',
    'LBL_KPI_RESULT' => 'KPI Result'
);