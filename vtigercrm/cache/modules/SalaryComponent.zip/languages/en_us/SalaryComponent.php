<?php

$languageStrings = array(
        'LBL_SalaryComponent_INFORMATION' => 'Salary Components Detail',
        'SINGLE_SalaryComponent' => 'Salary Components',
        'SINGLE_SalaryComponent' => 'Salary Components',
);