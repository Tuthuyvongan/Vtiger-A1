<?php

$languageStrings = array(
        'LBL_RATING_INFORMATION' => 'Rating Information',
        'LBL_RANKING_INFORMATION' => 'Ranking',
        'SINGLE_Rating' => 'Rating',
        'LBL_BONUS_FINED' => 'Bonus/Fined'
);