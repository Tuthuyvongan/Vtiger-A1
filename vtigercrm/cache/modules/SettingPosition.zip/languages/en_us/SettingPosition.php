<?php

$languageStrings = array(
        'LBL_SP_INFORMATION' => 'Setting Position',
        'SINGLE_SettingPosition' => 'Setting Position'
);